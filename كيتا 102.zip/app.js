// تسجيل المستخدم
const registerForm = document.getElementById('registerForm');
if (registerForm) {
  registerForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const username = document.getElementById('newUsername').value;
    const password = document.getElementById('newPassword').value;
    const role = document.getElementById('role').value;

    let users = JSON.parse(localStorage.getItem('users')) || [];
    if (users.find(u => u.username === username)) {
      alert('اسم المستخدم مستخدم مسبقًا');
      return;
    }
    users.push({ username, password, role });
    localStorage.setItem('users', JSON.stringify(users));
    alert('تم التسجيل بنجاح!');
    window.location.href = 'index.html';
  });
}

// تسجيل الدخول
const loginForm = document.getElementById('loginForm');
if (loginForm) {
  loginForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    let users = JSON.parse(localStorage.getItem('users')) || [];
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
      localStorage.setItem('currentUser', JSON.stringify(user));
      alert('تم تسجيل الدخول بنجاح!');
      window.location.href = 'dashboard.html';
    } else {
      alert('اسم المستخدم أو كلمة المرور غير صحيحة');
    }
  });
}

// لوحة التحكم
const currentUser = JSON.parse(localStorage.getItem('currentUser'));
if (currentUser && document.getElementById('welcomeMsg')) {
  document.getElementById('welcomeMsg').innerText = `مرحبًا، ${currentUser.username} (${currentUser.role})`;
  if (currentUser.role === 'player') {
    document.getElementById('playerSection').style.display = 'block';
  } else if (currentUser.role === 'club') {
    document.getElementById('clubSection').style.display = 'block';
  } else if (currentUser.role === 'agent') {
    document.getElementById('agentSection').style.display = 'block';
  }
}

// تسجيل الخروج
function logout() {
  localStorage.removeItem('currentUser');
  window.location.href = 'index.html';
}
